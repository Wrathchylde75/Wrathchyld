Scripts to make common developer tasks easy to type.
