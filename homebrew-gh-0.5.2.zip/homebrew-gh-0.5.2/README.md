This is a Homebrew tap repository that provides the `gh` formula for GitHub CLI.

## Install for macOS
### Homebrew
To install:
```sh
brew install github/gh/gh
```
To upgrade:
```sh
brew upgrade gh
```

## Other platforms

See <https://github.com/cli/cli#installation>
