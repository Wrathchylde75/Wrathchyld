package shared

type Visibility string

const (
	All      = "all"
	Private  = "private"
	Selected = "selected"
)
